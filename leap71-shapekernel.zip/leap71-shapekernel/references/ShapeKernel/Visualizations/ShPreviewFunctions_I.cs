//
// SPDX-License-Identifier: Apache-2.0
//
// The LEAP 71 ShapeKernel is an open source geometry engine
// specifically for use in Computational Engineering Models (CEM).
//
// For more information, please visit https://leap71.com/shapekernel
// 
// This project is developed and maintained by LEAP 71 - © 2024 by LEAP 71
// https://leap71.com
//
// Computational Engineering will profoundly change our physical world in the
// years ahead. Thank you for being part of the journey.
//
// We have developed this library to be used widely, for both commercial and
// non-commercial projects alike. Therefore, have released it under a permissive
// open-source license.
// 
// The LEAP 71 ShapeKernel is based on the PicoGK compact computational geometry 
// framework. See https://picogk.org for more information.
//
// LEAP 71 licenses this file to you under the Apache License, Version 2.0
// (the "License"); you may not use this file except in compliance with the
// License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, THE SOFTWARE IS
// PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED.
//
// See the License for the specific language governing permissions and
// limitations under the License.   
//

using System.Numerics;
using PicoGK;


namespace Leap71
{
    namespace ShapeKernel
    {
        public partial class Sh
        {
            public static uint nNumberOfGroups = 0;
            
            public static int PreviewMesh(
                Mesh        oMesh,
                ColorFloat  clrColor,
                float       fTransparency   = 0.9f,
                float       fMetallic       = 0.4f,
                float       fRoughness      = 0.7f)
            {
                int iNextGroupId    = (int)nNumberOfGroups;
                ColorFloat clr      = new ColorFloat(clrColor, fTransparency);
                Library.oViewer().SetGroupMaterial(iNextGroupId,
                                            clr,
                                            fMetallic,
                                            fRoughness);
                Library.oViewer().Add(oMesh, iNextGroupId);
                nNumberOfGroups++;
                return (int)(nNumberOfGroups - 1);
            }

            public static int PreviewVoxels(
                Voxels      oVoxels,
                ColorFloat  clrColor,
                float       fTransparency   = 0.9f,
                float       fMetallic       = 0.4f,
                float       fRoughness      = 0.7f)
            {
                int iNextGroupId    = (int)nNumberOfGroups;
                ColorFloat clr      = new ColorFloat(clrColor, fTransparency);
                Library.oViewer().SetGroupMaterial(iNextGroupId,
                                            clr,
                                            fMetallic,
                                            fRoughness);
                Library.oViewer().Add(oVoxels, iNextGroupId);
                nNumberOfGroups++;
                return (int)(nNumberOfGroups - 1);
            }

            public static int PreviewLattice(
                Lattice     oLattice,
                ColorFloat  clrColor,
                float       fTransparency   = 0.9f,
                float       fMetallic       = 0.4f,
                float       fRoughness      = 0.7f)
            {
                int iNextGroupId    = (int)nNumberOfGroups;
                ColorFloat clr      = new ColorFloat(clrColor, fTransparency);
                Library.oViewer().SetGroupMaterial(iNextGroupId,
                                            clr,
                                            fMetallic,
                                            fRoughness);
                Voxels oVoxels = new Voxels(oLattice);
                Library.oViewer().Add(oVoxels, iNextGroupId);
                nNumberOfGroups++;
                return (int)(nNumberOfGroups - 1);
            }

            public static void PreviewPoint(
                Vector3     vecPt,
                float       fBeam,
                ColorFloat  clrColor,
                float       fTransparency   = 0.9f,
                float       fMetallic       = 0.4f,
                float       fRoughness      = 0.7f)
            {
                BaseSphere oBall = new (new (vecPt), fBeam);
                PreviewMesh(oBall.mshConstruct(), clrColor, fTransparency, fMetallic, fRoughness);
            }

            public static void PreviewBeam(
                Vector3     vecPt1,
                float       fBeam1,
                Vector3     vecPt2,
                float       fBeam2,
                ColorFloat  clrColor,
                float       fTransparency   = 0.9f,
                float       fMetallic       = 0.4f,
                float       fRoughness      = 0.7f)
            {
                Lattice oLattice = new Lattice();
                oLattice.AddBeam(vecPt1, fBeam1, vecPt2, fBeam2, true);
                PreviewLattice(oLattice, clrColor, fTransparency, fMetallic, fRoughness);
            }

            public static void PreviewLine(
                List<Vector3>   aPoints,
                ColorFloat      clrColor)
            {
                int iNextGroupId = (int)nNumberOfGroups;
                PolyLine oLine = new PolyLine(clrColor);
                for (int i = 0; i < aPoints.Count; i++)
                {
                    oLine.nAddVertex(aPoints[i]);
                }
                Library.oViewer().Add(oLine, iNextGroupId);
                nNumberOfGroups++;
            }

            public static void PreviewLine(
                Vector3     vecPt1, 
                Vector3     vecPt2,
                ColorFloat  clrColor)
            {
                int iNextGroupId        = (int)nNumberOfGroups;
                PolyLine oLine          = new PolyLine(clrColor);
                List<Vector3> aPoints   = new () {vecPt1, vecPt2};
                for (int i = 0; i < aPoints.Count; i++)
                {
                    oLine.nAddVertex(aPoints[i]);
                }
                Library.oViewer().Add(oLine, iNextGroupId);
                nNumberOfGroups++;
            }

            public static void PreviewGrid(
                List<List<Vector3>> aGrid,
                ColorFloat          clrColor)
            {
                for (int i = 0; i < aGrid.Count; i++)
                {
                    PreviewLine(aGrid[i], clrColor);
                }
                aGrid = GridOperations.aGetInverseGrid(aGrid);
                for (int i = 0; i < aGrid.Count; i++)
                {
                    PreviewLine(aGrid[i], clrColor);
                }
            }

            public static void PreviewEdges(
                List<List<Vector3>> aEdges,
                ColorFloat          clrColor)
            {
                for (int i = 0; i < aEdges.Count; i++)
                {
                    PreviewLine(aEdges[i], clrColor);
                }
            }

            public static void PreviewPointCloud(
                List<Vector3>   aPoints,
                float           fBeam,
                ColorFloat      clrColor,
                float           fTransparency   = 0.9f,
                float           fMetallic       = 0.4f,
                float           fRoughness      = 0.7f)
            {
                for (int i = 0; i < aPoints.Count; i++)
                {
                    PreviewPoint(aPoints[i], fBeam, clrColor, fTransparency, fMetallic, fRoughness);
                }
            }

            public static void PreviewFrame(
                LocalFrame  oFrame,
                float       fSize)
            {
                PolyLine oXLine = new(Cp.clrRed);
                oXLine.nAddVertex(oFrame.vecGetPosition());
                oXLine.nAddVertex(oFrame.vecGetPosition() + fSize * oFrame.vecGetLocalX());
                oXLine.AddArrow(0.2f * fSize);

                PolyLine oYLine = new(Cp.clrGreen);
                oYLine.nAddVertex(oFrame.vecGetPosition());
                oYLine.nAddVertex(oFrame.vecGetPosition() + fSize * oFrame.vecGetLocalY());
                oYLine.AddArrow(0.2f * fSize);

                PolyLine oZLine = new(Cp.clrBlue);
                oZLine.nAddVertex(oFrame.vecGetPosition());
                oZLine.nAddVertex(oFrame.vecGetPosition() + fSize * oFrame.vecGetLocalZ());
                oZLine.AddArrow(0.2f * fSize);

                float fPointRadius = MathF.Min(0.5f, 0.05f * fSize);
                PreviewPoint(oFrame.vecGetPosition(), fPointRadius, Cp.clrBlack);
                Library.oViewer().Add(oXLine);
                Library.oViewer().Add(oYLine);
                Library.oViewer().Add(oZLine);
            }

            public static void PreviewFrames(
                Frames  aFrames,
                float   fSize)
            {
                float fTotalLength  = SplineOperations.fGetTotalLength(aFrames.aGetPoints(100));
                uint nSamples       = (uint)(2f * fTotalLength / fSize);
                for (int i = 0; i < nSamples; i++)
                {
                    float fLR           = 1f / (nSamples - 1f) * i;
                    LocalFrame oFrame   = aFrames.oGetLocalFrame(fLR);
                    PreviewFrame(oFrame, fSize);
                }
            }

            public static void PreviewCircleSection(
                LocalFrame  oFrame,
                float       fRadius,
                ColorFloat  clrColor,
                float       fTransparency   = 0.9f,
                float       fMetallic       = 0.4f,
                float       fRoughness      = 0.7f)
            {
                Lattice oLattice    = new Lattice();
                Vector3 vecPt1      = oFrame.vecGetPosition();
                Vector3 vecPt2      = vecPt1 + 1f * oFrame.vecGetLocalZ();
                oLattice.AddBeam(vecPt1, fRadius, vecPt2, fRadius, false);
                PreviewLattice(oLattice, clrColor, fTransparency, fMetallic, fRoughness);
            }

            public static void PreviewCircle(
                LocalFrame  oFrame,
                float       fRadius,
                ColorFloat  clrColor)
            {
                List<Vector3> aPoints   = new List<Vector3>();
                uint nSamples           = 100;
                for (uint i = 0; i < nSamples; i++)
                {
                    float fPhi      = 2f * MathF.PI / (float)(nSamples - 1) * i;
                    Vector3 vecRel  = VecOperations.vecGetCylPoint(fRadius, fPhi, 0f);
                    Vector3 vecPt   = VecOperations.vecTranslatePointOntoFrame(oFrame, vecRel);
                    aPoints.Add(vecPt);
                }
                PreviewLine(aPoints, clrColor);
            }

            public static void PreviewCircle(
                Vector3     vecCentre,
                float       fRadius,
                ColorFloat  clrColor)
            {
                LocalFrame oFrame = new (vecCentre);
                PreviewCircle(oFrame, fRadius, clrColor);
            }

            /// <summary>
            /// Constructs all triangle edges within the mesh from wireframe lines.
            /// Do not use this function for very large, finely-resolved meshes.
            /// </summary>
            public static void PreviewMeshWireframe(
                Mesh            msh,
                ColorFloat      clrColor)
            {
                int nTriangles = msh.nTriangleCount();
                for (int i = 0; i < nTriangles; i++)
                {
                    Triangle oTri   = msh.oTriangleAt(i);
                    Vector3 vecA    = msh.vecVertexAt(oTri.A);
                    Vector3 vecB    = msh.vecVertexAt(oTri.B);
                    Vector3 vecC    = msh.vecVertexAt(oTri.C);
                    List<Vector3> aBound = new () {vecA, vecB, vecC, vecA};
                    Preview(aBound, clrColor);
                }
            }

            public static void PreviewCylinderWireframe(
                BaseCylinder    oCyl,
                ColorFloat      clrColor,
                uint            nRadialSamples = 4,
                uint            nLengthSamples = 10)
            {
                // length samples
                for (uint nLengthSample = 0; nLengthSample < nLengthSamples; nLengthSample++)
                {
                    uint nSamples           = 100;
                    float fRadiusRatio      = 1f;
                    float fLengthRatio      = 1f / (float)(nLengthSamples - 1) * nLengthSample;
                    List<Vector3> aPoints   = new List<Vector3>();
                    for (uint i = 0; i < nSamples; i++)
                    {
                        float fPhiRatio     = 1f / (float)(nSamples - 1) * i;
                        aPoints.Add(oCyl.vecGetSurfacePoint(fLengthRatio, fPhiRatio, fRadiusRatio));
                    }
                    PreviewLine(aPoints, clrColor);
                }

                // radial samples
                for (uint nRadialSample = 0; nRadialSample < nRadialSamples; nRadialSample++)
                {
                    uint nSamples           = 1000;
                    float fRadiusRatio      = 1f;
                    float fPhiRatio         = 1f / (float)(nRadialSamples) * nRadialSample;
                    List<Vector3> aPoints   = new List<Vector3>();
                    for (uint i = 0; i < nSamples; i++)
                    {
                        float fLengthRatio  = 1f / (float)(nSamples - 1) * i;
                        aPoints.Add(oCyl.vecGetSurfacePoint(fLengthRatio, fPhiRatio, fRadiusRatio));
                    }
                    PreviewLine(aPoints, clrColor);
                }
            }

            public static void PreviewPipeWireframe(
                BasePipe    oCyl,
                ColorFloat  clrColor,
                uint        nRadialSamples = 4,
                uint        nLengthSamples = 10)
            {
                // length samples
                for (uint nLengthSample = 0; nLengthSample < nLengthSamples; nLengthSample++)
                {
                    uint nSamples           = 100;
                    float fRadiusRatio      = 1f;
                    float fLengthRatio      = 1f / (float)(nLengthSamples - 1) * nLengthSample;
                    List<Vector3> aPoints   = new List<Vector3>();
                    for (uint i = 0; i < nSamples; i++)
                    {
                        float fPhiRatio     = 1f / (float)(nSamples - 1) * i;
                        aPoints.Add(oCyl.vecGetSurfacePoint(fLengthRatio, fPhiRatio, fRadiusRatio));
                    }
                    PreviewLine(aPoints, clrColor);
                }

                // length samples
                for (uint nLengthSample = 0; nLengthSample < nLengthSamples; nLengthSample++)
                {
                    uint nSamples           = 100;
                    float fRadiusRatio      = 0f;
                    float fLengthRatio      = 1f / (float)(nLengthSamples - 1) * nLengthSample;
                    List<Vector3> aPoints   = new List<Vector3>();
                    for (uint i = 0; i < nSamples; i++)
                    {
                        float fPhiRatio     = 1f / (float)(nSamples - 1) * i;
                        aPoints.Add(oCyl.vecGetSurfacePoint(fLengthRatio, fPhiRatio, fRadiusRatio));
                    }
                    PreviewLine(aPoints, clrColor);
                }

                // radial samples
                for (uint nRadialSample = 0; nRadialSample < nRadialSamples; nRadialSample++)
                {
                    uint nSamples           = 100;
                    float fRadiusRatio      = 1f;
                    float fPhiRatio         = 1f / (float)(nRadialSamples) * nRadialSample;
                    List<Vector3> aPoints   = new List<Vector3>();
                    for (uint i = 0; i < nSamples; i++)
                    {
                        float fLengthRatio  = 1f / (float)(nSamples - 1) * i;
                        aPoints.Add(oCyl.vecGetSurfacePoint(fLengthRatio, fPhiRatio, fRadiusRatio));
                    }
                    PreviewLine(aPoints, clrColor);
                }

                // radial samples
                for (uint nRadialSample = 0; nRadialSample < nRadialSamples; nRadialSample++)
                {
                    uint nSamples           = 100;
                    float fRadiusRatio      = 0f;
                    float fPhiRatio         = 1f / (float)(nRadialSamples) * nRadialSample;
                    List<Vector3> aPoints   = new List<Vector3>();
                    for (uint i = 0; i < nSamples; i++)
                    {
                        float fLengthRatio  = 1f / (float)(nSamples - 1) * i;
                        aPoints.Add(oCyl.vecGetSurfacePoint(fLengthRatio, fPhiRatio, fRadiusRatio));
                    }
                    PreviewLine(aPoints, clrColor);
                }
            }

            public static void PreviewBoxWireframe(
                BaseBox     oBox,
                ColorFloat  clrColor)
            {
                // lower face
                PreviewLine(new List<Vector3>()
                {
                    oBox.vecGetSurfacePoint(-1, -1, 0),
                    oBox.vecGetSurfacePoint(-1,  1, 0),
                    oBox.vecGetSurfacePoint( 1,  1, 0),
                    oBox.vecGetSurfacePoint( 1, -1, 0),
                    oBox.vecGetSurfacePoint(-1, -1, 0)
                }, clrColor);


                // upper face
                PreviewLine(new List<Vector3>()
                {
                    oBox.vecGetSurfacePoint(-1, -1, 1),
                    oBox.vecGetSurfacePoint(-1,  1, 1),
                    oBox.vecGetSurfacePoint( 1,  1, 1),
                    oBox.vecGetSurfacePoint( 1, -1, 1),
                    oBox.vecGetSurfacePoint(-1, -1, 1)
                }, clrColor);

                // side pillars
                PreviewLine(new List<Vector3>()
                {
                    oBox.vecGetSurfacePoint(-1, -1, 0),
                    oBox.vecGetSurfacePoint(-1, -1, 1),
                }, clrColor);

                PreviewLine(new List<Vector3>()
                {
                    oBox.vecGetSurfacePoint(-1, 1, 0),
                    oBox.vecGetSurfacePoint(-1, 1, 1),
                }, clrColor);

                PreviewLine(new List<Vector3>()
                {
                    oBox.vecGetSurfacePoint(1, 1, 0),
                    oBox.vecGetSurfacePoint(1, 1, 1),
                }, clrColor);

                PreviewLine(new List<Vector3>()
                {
                    oBox.vecGetSurfacePoint(1, -1, 0),
                    oBox.vecGetSurfacePoint(1, -1, 1),
                }, clrColor);
            }

            public static void PreviewBoxWireframe(
                BBox3       oBBox,
                ColorFloat  clrColor)
            {
                Vector3 vecBase = VecOperations.vecSetZ(0.5f * (oBBox.vecMax + oBBox.vecMin), oBBox.vecMin.Z);
                float fLength   = (oBBox.vecMax - oBBox.vecMin).Z;
                float fWidth    = (oBBox.vecMax - oBBox.vecMin).X;
                float fDepth    = (oBBox.vecMax - oBBox.vecMin).Y;
                BaseBox oBox    = new BaseBox(new LocalFrame(vecBase), fLength, fWidth, fDepth);
                PreviewBoxWireframe(oBox, clrColor);
            }

            public static void PreviewRingWireframe(
                BaseRing    oRing, 
                ColorFloat  clr,
                uint        nRadialSamples = 4,
                uint        nLengthSamples = 10) 
            {
                // length samples
                for (uint nLengthSample = 0; nLengthSample < nLengthSamples; nLengthSample++)
                {
                    uint nSamples           = 100;
                    float fRadiusRatio      = 1f;
                    float fLengthRatio      = 1f / (nLengthSamples - 1f) * nLengthSample;
                    List<Vector3> aPoints   = new List<Vector3>();
                    for (uint i = 0; i < nSamples; i++)
                    {
                        float fPhiRatio     = 1f / (nSamples - 1f) * i;
                        aPoints.Add(oRing.vecGetSurfacePoint(fLengthRatio, fPhiRatio, fRadiusRatio));
                    }
                    PreviewLine(aPoints, clr);
                }

                // radial samples
                for (uint nRadialSample = 0; nRadialSample < nRadialSamples; nRadialSample++)
                {
                    uint nSamples           = 500;
                    float fRadiusRatio      = 1f;
                    float fPhiRatio         = 1f / (nRadialSamples - 1f) * nRadialSample;
                    List<Vector3> aPoints   = new List<Vector3>();
                    for (uint i = 0; i < nSamples; i++)
                    {
                        float fLengthRatio  = 1f / (nSamples - 1f) * i;
                        aPoints.Add(oRing.vecGetSurfacePoint(fLengthRatio, fPhiRatio, fRadiusRatio));
                    }
                    PreviewLine(aPoints, clr);
                }
            }
        }
    }
}